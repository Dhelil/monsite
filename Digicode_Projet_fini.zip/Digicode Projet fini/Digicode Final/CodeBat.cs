﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Digicode_Final
{
    public partial class CodeBat : Form
    {
        public CodeBat()
        {
            InitializeComponent();
        }

        private string input = "";
        private int trys = 0;

        private void listViewCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewCode.SelectedItems.Count != 1) return;

            input += listViewCode.SelectedItems[0].SubItems[0].Text;
            RefreshInput();
            if (input.Length == 6)
            {
                //List<string[]> mList = MData.MyExcel("fichier.csv", true);

                perso[] persoArray = MData.StringsToPerso(MData.MyExcel("digicod_perso.csv", true));
                bool foundPerso = false;
                int i = 0;
                while (i < persoArray.Length && !foundPerso)
                {
                    if (persoArray[i].matricule == matriculeInBat.Text && persoArray[i].autorisation == "E") foundPerso = true;
                    i++;
                }

                secure[] secureList = MData.StringsToSecure(MData.MyExcel("digicod_secure.csv", true));
                bool foundSecure = false;
                bool dateCorrect = false;
                DateTime now = DateTime.Now;
                i = 0;
                while(i < secureList.Length && !foundSecure)
                {
                    if (secureList[i].porte == "E" && secureList[i].code == input)
                    {
                        foundSecure = true;
                        if (now > DateTime.Parse(secureList[i].date_debut) &&
                            now < DateTime.Parse(secureList[i].date_fin))
                                dateCorrect = true;
                    }
                    i++;
                }

                if(!foundPerso || !foundSecure)
                {
                    MessageBox.Show("Code ou matricule invalide.");
                    input = "";
                    RefreshInput();
                    trys++;
                    if (trys == 3)
                    {
                        listViewCode.Enabled = false;
                        error err = new();
                        err.matricule = matriculeInBat.Text;
                        err.porte = "E";
                        err.date = DateTime.Now.ToShortDateString();
                        err.heure = DateTime.Now.ToShortTimeString();
                        MData.ErrorTrace(err);
                        MessageBox.Show("3 essais, c'est finit !\n(Revenez au menu pour réessayer)");
                    }
                }
                else if(!dateCorrect)
                {
                    MessageBox.Show("Période de validité invalide !\n(Ceci ne compte pas comme une erreur)");
                    input = "";
                    RefreshInput();
                }
                else
                {
                    MessageBox.Show("Code et matricule bon. Période valide.\nRedirection vers le menu.");
                    Form1.inBat = true;
                    Hide();
                    new Form1().Show();
                }
            }
        }

        private void RefreshInput()
        {
            string builder = "";
            for (int i = 0; i < input.Length; i++)
            {
                builder += "*";
            }
            typingCode.Text = builder;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Form1().Show();
        }
    }
}
