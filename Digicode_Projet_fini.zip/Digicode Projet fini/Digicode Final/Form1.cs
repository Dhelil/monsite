using System.Runtime;

namespace Digicode_Final
{
    public partial class Form1 : Form
    {
        public static bool inBat = false, inInfo = false;

        public Form1()
        {
            InitializeComponent();

            RefreshDisplay();
        }

        private void RefreshDisplay()
        {
            bool accesBat = !inBat;
            bool accesInfo = inBat && !inInfo;
            bool accesListError = inInfo;

            buttonBat.Enabled = accesBat;
            buttonSalleInfo.Enabled = accesInfo;
            buttonListErrors.Enabled = accesListError;

            stateBat.Text = accesBat ? "Autoris�" : "Indispo";
            stateInfo.Text = accesInfo ? "Autoris�" : "Indispo";
            stateListError.Text = accesListError ? "Autoris�" : "Indispo";

            stateBat.ForeColor = accesBat ? Color.Green : Color.Red;
            stateInfo.ForeColor = accesInfo ? Color.Green : Color.Red;
            stateListError.ForeColor = accesListError ? Color.Green : Color.Red;
        }

        private void buttonBat_Click(object sender, EventArgs e)
        {
            Hide();
            new CodeBat().Show();
        }

        private void buttonSalleInfo_Click(object sender, EventArgs e)
        {
            Hide();
            new CodeInfo().Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            buttonListErrors_Click(sender, e);
        }

        private void buttonListErrors_Click(object sender, EventArgs e)
        {
            Hide();
            new ErrorList().Show();
        }
    }
}