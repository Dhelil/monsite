﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Digicode_Final
{
    public partial class ErrorList : Form
    {
        public ErrorList()
        {
            InitializeComponent();

            error[] errors = MData.StringsToErrors(MData.MyExcel("digicod_erreur.csv", true));
            foreach(error error in errors) {
                ListViewItem item = new(error.matricule);
                item.SubItems.Add(error.date);
                item.SubItems.Add(error.heure);
                item.SubItems.Add(error.porte);
                errorListView.Items.Add(item);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Form1().Show();
        }

        private void errorListView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
