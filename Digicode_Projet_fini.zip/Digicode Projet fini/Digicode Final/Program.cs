using System.Runtime.InteropServices;
//using Excel = Microsoft.Office.Interop.Excel;

namespace Digicode_Final
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
        //Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@"myres/digicod_secure.xlsx");


        //public static List<secure> OldMyExcel(string fileName, int col, bool jumpFirst)
        //{
        //    string sCurrentDirectory = AppDomain.CurrentDomain.BaseDirectory;
        //    string sFile = System.IO.Path.Combine(sCurrentDirectory, @"..\..\..\myres\" + fileName);
        //    string sFilePath = Path.GetFullPath(sFile);

        //    Excel.Application xlApp = new Excel.Application();
        //    Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(sFilePath);
        //    Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
        //    Excel.Range xlRange = xlWorksheet.UsedRange;

        //    //

        //    bool doing = true;
        //    int i = 1;
        //    if (jumpFirst) i++;
        //    List<secure> list = new();
        //    var cells = xlRange.Cells;
        //    while (doing)
        //    {
        //        secure s = new secure();
        //        string[] builder = new string[col];
        //        int j = 1;
        //        while(j <= col && doing)
        //        {
        //            if (cells[i, j] != null && cells[i, j].Value2 != null && doing)
        //                builder[j - 1] = cells[i, j].Value2.ToString();
        //            else doing = false;
        //            j++;
        //        }
        //        s.porte = builder[0];
        //        s.date_debut = builder[1];
        //        s.date_fin = builder[2];
        //        s.code = builder[3];
        //        if(doing) list.Add(s);
        //        i++;
        //    }

        //    //

        //    GC.Collect();
        //    GC.WaitForPendingFinalizers();

        //    //rule of thumb for releasing com objects:
        //    //  never use two dots, all COM objects must be referenced and released individually
        //    //  ex: [somthing].[something].[something] is bad

        //    //release com objects to fully kill excel process from running in the background
        //    Marshal.ReleaseComObject(xlRange);
        //    Marshal.ReleaseComObject(xlWorksheet);

        //    //close and release
        //    xlWorkbook.Close(0);
        //    Marshal.ReleaseComObject(xlWorkbook);

        //    //quit and release
        //    xlApp.Quit();
        //    Marshal.ReleaseComObject(xlApp);

        //    return list;
        //}
    }
}