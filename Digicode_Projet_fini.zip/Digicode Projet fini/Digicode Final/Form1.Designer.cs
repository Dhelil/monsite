﻿namespace Digicode_Final
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonListErrors = new System.Windows.Forms.Button();
            this.buttonBat = new System.Windows.Forms.Button();
            this.buttonSalleInfo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.stateBat = new System.Windows.Forms.Label();
            this.stateInfo = new System.Windows.Forms.Label();
            this.stateListError = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonListErrors
            // 
            this.buttonListErrors.BackColor = System.Drawing.Color.IndianRed;
            this.buttonListErrors.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonListErrors.ForeColor = System.Drawing.Color.White;
            this.buttonListErrors.Location = new System.Drawing.Point(501, 284);
            this.buttonListErrors.Name = "buttonListErrors";
            this.buttonListErrors.Size = new System.Drawing.Size(189, 49);
            this.buttonListErrors.TabIndex = 7;
            this.buttonListErrors.Text = "Liste d\'erreurs";
            this.buttonListErrors.UseVisualStyleBackColor = false;
            this.buttonListErrors.Click += new System.EventHandler(this.buttonListErrors_Click);
            // 
            // buttonBat
            // 
            this.buttonBat.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.buttonBat.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonBat.ForeColor = System.Drawing.Color.White;
            this.buttonBat.Location = new System.Drawing.Point(111, 284);
            this.buttonBat.Name = "buttonBat";
            this.buttonBat.Size = new System.Drawing.Size(189, 49);
            this.buttonBat.TabIndex = 6;
            this.buttonBat.Text = "Accès bâtiment";
            this.buttonBat.UseVisualStyleBackColor = false;
            this.buttonBat.Click += new System.EventHandler(this.buttonBat_Click);
            // 
            // buttonSalleInfo
            // 
            this.buttonSalleInfo.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.buttonSalleInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonSalleInfo.ForeColor = System.Drawing.Color.White;
            this.buttonSalleInfo.Location = new System.Drawing.Point(306, 284);
            this.buttonSalleInfo.Name = "buttonSalleInfo";
            this.buttonSalleInfo.Size = new System.Drawing.Size(189, 49);
            this.buttonSalleInfo.TabIndex = 5;
            this.buttonSalleInfo.Text = "Accès salle info";
            this.buttonSalleInfo.UseVisualStyleBackColor = false;
            this.buttonSalleInfo.Click += new System.EventHandler(this.buttonSalleInfo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(262, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(270, 33);
            this.label1.TabIndex = 4;
            this.label1.Text = "DIGICODE (Grp. 6)";
            // 
            // stateBat
            // 
            this.stateBat.AutoSize = true;
            this.stateBat.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.stateBat.Location = new System.Drawing.Point(176, 336);
            this.stateBat.Name = "stateBat";
            this.stateBat.Size = new System.Drawing.Size(48, 23);
            this.stateBat.TabIndex = 8;
            this.stateBat.Text = "State";
            // 
            // stateInfo
            // 
            this.stateInfo.AutoSize = true;
            this.stateInfo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.stateInfo.Location = new System.Drawing.Point(374, 336);
            this.stateInfo.Name = "stateInfo";
            this.stateInfo.Size = new System.Drawing.Size(48, 23);
            this.stateInfo.TabIndex = 9;
            this.stateInfo.Text = "State";
            // 
            // stateListError
            // 
            this.stateListError.AutoSize = true;
            this.stateListError.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.stateListError.Location = new System.Drawing.Point(564, 336);
            this.stateListError.Name = "stateListError";
            this.stateListError.Size = new System.Drawing.Size(48, 23);
            this.stateListError.TabIndex = 10;
            this.stateListError.Text = "State";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.IndianRed;
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(599, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 82);
            this.button1.TabIndex = 11;
            this.button1.Text = "Liste d\'erreurs (accessible tout le temps pour debug)";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.stateListError);
            this.Controls.Add(this.stateInfo);
            this.Controls.Add(this.stateBat);
            this.Controls.Add(this.buttonListErrors);
            this.Controls.Add(this.buttonBat);
            this.Controls.Add(this.buttonSalleInfo);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonListErrors;
        private Button buttonBat;
        private Button buttonSalleInfo;
        private Label label1;
        private Label stateBat;
        private Label stateInfo;
        private Label stateListError;
        private Button button1;
    }
}