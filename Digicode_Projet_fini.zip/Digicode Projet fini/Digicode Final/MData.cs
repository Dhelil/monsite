﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Digicode_Final
{
    public static class MData
    {
        private static string getFilePath(string fileName)
        {
            string sCurrentDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string sFile = Path.Combine(sCurrentDirectory, @"..\..\..\myres\" + fileName);
            string sFilePath = Path.GetFullPath(sFile);
            return sFilePath;
        }

        public static List<string[]> MyExcel(string fileName, bool jumpFirst)
        {
            StreamReader stream = new StreamReader(getFilePath(fileName));
            bool doing = true;
            if (jumpFirst) stream.ReadLine();
            List<string[]> list = new();
            string ligneFichier;

            int i = 0;
            while ((ligneFichier = stream.ReadLine()) != null)
            {
                string[] cols;
                cols = ligneFichier.Split(';');

                if (doing) list.Add(cols);
                i++;
            }

            stream.Close();

            return list;
        }

        public static void ErrorTrace(error e)
        {
            StreamWriter stream = new StreamWriter(getFilePath("digicod_erreur.csv"), true);
            stream.WriteLine(e.matricule + ";" + e.date + ";" + e.heure + ";" + e.porte);
            stream.Close();
        }

        public static secure[] StringsToSecure(List<string[]> strings)
        {
            secure[] secureArray = new secure[strings.Count];
            for(int i = 0; i < strings.Count; i++)
            {
                secure s = new secure();
                s.porte = strings[i][0];
                s.date_debut = strings[i][1];
                s.date_fin = strings[i][2];
                s.code = strings[i][3];
                secureArray[i] = s;
            }
            return secureArray;
        }

        public static perso[] StringsToPerso(List<string[]> strings)
        {
            perso[] secureArray = new perso[strings.Count];
            for (int i = 0; i < strings.Count; i++)
            {
                perso s = new perso();
                s.matricule = strings[i][0];
                s.nom = strings[i][1];
                s.prenom = strings[i][2];
                s.autorisation = strings[i][3];
                secureArray[i] = s;
            }
            return secureArray;
        }

        public static error[] StringsToErrors(List<string[]> strings)
        {
            error[] secureArray = new error[strings.Count];
            for (int i = 0; i < strings.Count; i++)
            {
                error s = new error();
                s.matricule = strings[i][0];
                s.date = strings[i][1];
                s.heure = strings[i][2];
                s.porte = strings[i][3];
                secureArray[i] = s;
            }
            return secureArray;
        }
    }

    public struct secure
    {
        public string porte;
        public string date_debut;
        public string date_fin;
        public string code;
    }

    public struct perso
    {
        public string matricule;
        public string nom;
        public string prenom;
        public string autorisation;
    }

    public struct error
    {
        public string matricule;
        public string date;
        public string heure;
        public string porte;
    }
}
