﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Digicode_Final
{
    public partial class CodeInfo : Form
    {
        public CodeInfo()
        {
            InitializeComponent();
        }

        private string input = "";
        private int trys = 0;

        private void RefreshInput()
        {
            string builder = "";
            for (int i = 0; i < input.Length; i++)
            {
                builder += "*";
            }
            typingCode.Text = builder;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Form1().Show();
        }

        private void listViewCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewCodeInfo.SelectedItems.Count != 1) return;

            input += listViewCodeInfo.SelectedItems[0].SubItems[0].Text;
            RefreshInput();
            if (input.Length == 6)
            {
                perso[] persoArray = MData.StringsToPerso(MData.MyExcel("digicod_perso.csv", true));
                bool foundPerso = false;
                int i = 0;
                while (i < persoArray.Length && !foundPerso)
                {
                    if (persoArray[i].matricule == matriculeInInfo.Text && persoArray[i].autorisation == "I") foundPerso = true;
                    i++;
                }

                secure[] secureList = MData.StringsToSecure(MData.MyExcel("digicod_secure.csv", true));
                bool foundSecure = false;
                bool dateCorrect = false;
                DateTime now = DateTime.Now;
                i = 0;
                while (i < secureList.Length && !foundSecure)
                {
                    if (secureList[i].porte == "I" && secureList[i].code == input)
                    {
                        foundSecure = true;
                        if (now > DateTime.Parse(secureList[i].date_debut) &&
                            now < DateTime.Parse(secureList[i].date_fin))
                            dateCorrect = true;
                    }
                    i++;
                }

                if (!foundPerso || !foundSecure)
                {
                    MessageBox.Show("Code ou matricule invalide.");
                    input = "";
                    RefreshInput();
                    trys++;
                    if (trys == 3)
                    {
                        listViewCodeInfo.Enabled = false;
                        error err = new();
                        err.matricule = matriculeInInfo.Text;
                        err.porte = "I";
                        err.date = DateTime.Now.ToShortDateString();
                        err.heure = DateTime.Now.ToShortTimeString();
                        MData.ErrorTrace(err);
                        MessageBox.Show("3 essais, c'est finit !\n(Revenez au menu pour réessayer)");
                    }
                }
                else if (!dateCorrect)
                {
                    MessageBox.Show("Période de validité invalide !\n(Ceci ne compte pas comme une erreur)");
                    input = "";
                    RefreshInput();
                }
                else
                {
                    MessageBox.Show("Code et matricule bon. Période valide.\nRedirection vers le menu.");
                    Form1.inInfo = true;
                    Hide();
                    new Form1().Show();
                }
            }
        }
    }
}
